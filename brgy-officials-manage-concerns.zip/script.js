document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('reportModal');
    const openBtns = document.querySelectorAll('.view-details-btn');
    const closeX = document.getElementById('closeModalX');
    const closeBtn = document.getElementById('closeModalBtn');

    // Function para buksan ang modal
    const openModal = () => {
        modal.classList.remove('hidden');
        // Stop background from scrolling
        document.body.style.overflow = 'hidden';
    };

    // Function para isara ang modal
    const closeModal = () => {
        modal.classList.add('hidden');
        document.body.style.overflow = 'auto';
    };

    // I-attach sa lahat ng "View Details" buttons
    openBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            openModal();
        });
    });

    // Event listeners para sa close buttons
    closeX.addEventListener('click', closeModal);
    closeBtn.addEventListener('click', closeModal);

    // Isara ang modal kapag clinick ang labas (overlay)
    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            closeModal();
        }
    });

    // Isara gamit ang Escape key
    window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && !modal.classList.contains('hidden')) {
            closeModal();
        }
    });
});

const reports = [
    {
        id: "#BRGY-2024-001",
        type: "Waste Management",
        resident: "Juan Dela Cruz",
        date: "2026-01-24",
        status: "Pending",
        description: "Garbage not collected for 3 days.",
        location: "Zone 1",
        assigned: "Maintenance Team A",
        images: ["https://via.placeholder.com/150"]
    },
    {
        id: "#BRGY-2024-002",
        type: "Street Lighting",
        resident: "Maria Clara",
        date: "2026-01-23",
        status: "Resolved",
        description: "Street light not working.",
        location: "Zone 2",
        assigned: "Maintenance Team B",
        images: ["https://via.placeholder.com/150"]
    }
];
const tabButtons = document.querySelectorAll('.tab-btn');

tabButtons.forEach(button => {
    button.addEventListener('click', () => {
        // Alisin ang 'active' class sa lahat ng buttons
        tabButtons.forEach(btn => btn.classList.remove('active'));
        
        // Idagdag ang 'active' class sa pinindot na button
        button.classList.add('active');
        
        // Dito mo rin pwedeng tawagin ang function para i-filter ang table
        const filterType = button.innerText.split(' ')[0].toLowerCase();
        console.log("Filtering by:", filterType);
    });
});

document.getElementById('sortFilter').addEventListener('change', function() {
    const sortValue = this.value;
    const tableBody = document.querySelector('tbody');
    const rows = Array.from(tableBody.querySelectorAll('tr'));

    rows.sort((a, b) => {
        // Halimbawa: Kunin ang text sa 4th column (Date Filed)
        const dateA = new Date(a.cells[3].innerText);
        const dateB = new Date(b.cells[3].innerText);

        if (sortValue === 'newest') return dateB - dateA;
        if (sortValue === 'oldest') return dateA - dateB;
        return 0;
    });

    // I-update ang table
    rows.forEach(row => tableBody.appendChild(row));
});